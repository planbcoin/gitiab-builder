/*
 *  PreferencePanes.h
 *  PreferencePanes
 *
 *  Copyright (c) 2001-2010 Apple. All rights reserved.
 *
 */

#import <PreferencePanes/NSPreferencePane.h>
