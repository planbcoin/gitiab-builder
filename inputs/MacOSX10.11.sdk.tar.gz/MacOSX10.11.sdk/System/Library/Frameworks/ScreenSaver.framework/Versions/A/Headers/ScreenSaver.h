/*
	ScreenSaver.h
	ScreenSaver
	Copyright (c) 2000-2, Apple Computer, Inc.
	All rights reserved.
*/

#import <ScreenSaver/ScreenSaverView.h>
#import <ScreenSaver/ScreenSaverDefaults.h>
