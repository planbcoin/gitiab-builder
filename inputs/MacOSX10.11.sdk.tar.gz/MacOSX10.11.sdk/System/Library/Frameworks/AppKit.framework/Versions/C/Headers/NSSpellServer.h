/*
        NSSpellServer.h
        Application Kit
        Copyright (c) 1990-2015, Apple Inc.
        All rights reserved.
*/


#warning "NSSpellServer class has moved to the Foundation framework.  Please adjust your header import."

